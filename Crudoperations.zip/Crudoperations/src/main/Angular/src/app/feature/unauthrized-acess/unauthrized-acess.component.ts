import { Component } from '@angular/core';

@Component({
  selector: 'app-unauthrized-acess',
  templateUrl: './unauthrized-acess.component.html',
  styleUrls: ['./unauthrized-acess.component.css']
})
export class UnauthrizedAcessComponent {

}
