import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Router,NavigationExtras } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  constructor(private http: HttpClient,private router: Router) {}

  ngOnInit(): void {}

  loginForm = new FormGroup({
    uname: new FormControl(''),
    pwd: new FormControl(''),
  });

  
  loginUser() {
    //console.log(JSON.stringify(this.loginForm.value));

    

    this.http.get<any>('http://127.0.0.1:9191/logintoApplication/'+this.loginForm.value.uname+'/'+this.loginForm.value.pwd)
			.subscribe(data => {
        
          if(data){
            console.log(data);
            let navigationExtras: NavigationExtras = {
              queryParams: {
                  "data"   : encodeURIComponent(data),
              }
          };
            this.router.navigate(['/app-dash-board'],navigationExtras);
          }}, (error:any) => { this.router.navigate(['/app-unauthrized-acess'])}
			);



  }

   

}
