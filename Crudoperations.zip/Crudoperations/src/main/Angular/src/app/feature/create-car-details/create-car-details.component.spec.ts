import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCarDetailsComponent } from './create-car-details.component';

describe('CreateCarDetailsComponent', () => {
  let component: CreateCarDetailsComponent;
  let fixture: ComponentFixture<CreateCarDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CreateCarDetailsComponent]
    });
    fixture = TestBed.createComponent(CreateCarDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
