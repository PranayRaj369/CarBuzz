import { Component, OnInit } from '@angular/core';

import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { CarBuzzzService } from 'src/app/services/car-buzzz.service';
import { Message } from 'primeng/api';

@Component({
  selector: 'app-create-car-details',
  templateUrl: './create-car-details.component.html',
  styleUrls: ['./create-car-details.component.css']
})
export class CreateCarDetailsComponent implements OnInit {

  value1: any;
  value2: any;
  name = 'Angular';
  queryParams:any =null;
  messages1!: Message[];
  singleCarDetailsForm!: FormGroup;
  updateBtn = false;

  multipleCarsDetailsForm!: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router,
     private carBuzzzService: CarBuzzzService,
     private route: ActivatedRoute
     ) {

  }
  ngOnInit(): void {
    this.createMultipleCarsForm();
    this.createSingleCarForm();
    this.queryParams = this.route.snapshot.queryParamMap
    if(this.queryParams && this.queryParams['params'] && this.queryParams['params']['car_brandName']){
      this.updateBtn = true;
      this.singleCarDetailsForm.patchValue(this.queryParams['params'])
    }
  }

  createSingleCarForm() {
    this.singleCarDetailsForm = this.fb.group({
      car_brandName: ['',Validators.required],
      car_model: ['',Validators.required],
      car_stock_count: ['',Validators.required],
      car_price: ['',Validators.required],
    });
  }
  createMultipleCarsForm() {
    this.multipleCarsDetailsForm = this.fb.group({
      quantities: this.fb.array([]),
    });
  }


  saveSingleCarDetails() {
    if(this.singleCarDetailsForm.valid){
    this.carBuzzzService.saveCarDetails(this.singleCarDetailsForm.value).subscribe(res => {
      console.log(res);
      if (res) {
        this.messages1 = [
          { severity: 'success', summary: 'Success', detail: `Car Details Created Sucessfully with Car ID: ${res.car_id} ` },
        ];
      }
    }, error => {
      this.messages1 = [
        { severity: 'error', summary: 'Error', detail: `Car Details Creation Failed` },
      ];
    });
  }
  }
  
  updateSingleCarDetails() {
    if(this.singleCarDetailsForm.valid){
    let requestParam = this.singleCarDetailsForm.value;
    requestParam['car_id'] = this.queryParams['params']['car_id'];
    console.log(this.queryParams['params']['car_id']);
    this.carBuzzzService.updateCarDetails(requestParam).subscribe(res => {
      console.log(res);
      if (res) {
        this.messages1 = [
          { severity: 'success', summary: 'Success', detail: `Car Details Updated Sucessfully with Car ID: ${res.car_id} ` },
        ];
      }
    }, error => {
      this.messages1 = [
        { severity: 'error', summary: 'Error', detail: `Car Details Creation Failed` },
      ];
    });
  }
  }

  onTabView(data: any) {
    if (data.index == 1) {
      this.addQuantity();
    }
    if (data.index == 0) {
      (<FormArray>this.multipleCarsDetailsForm.get('quantities')).clear();
    }
  }

  quantities(): FormArray {
    return this.multipleCarsDetailsForm.get("quantities") as FormArray
  }

  newQuantity(): FormGroup {
    return this.fb.group({
      car_brandName: [''],
      car_model: [''],
      car_stock_count: [],
      car_price: [],
    })
  }

  addQuantity() {
    this.quantities().push(this.newQuantity());
  }

  removeQuantity(i: number) {
    this.quantities().removeAt(i);
  }

  resetFormDetails() {
    this.singleCarDetailsForm.reset();
  }

  onSubmit() {
    
    this.carBuzzzService.saveCarsDetails(this.multipleCarsDetailsForm.value.quantities).subscribe(res => {
      console.log(res);
      debugger
      if (res) {
        let carsIds:any=[];
        res.forEach((cars: { car_id: any; }) => {
          carsIds.push(cars.car_id)
        });
        let ids=carsIds.toString();
        this.messages1 = [
          { severity: 'success', summary: 'Success', detail: `Car Details Created Sucessfully with CarS ID: ${ids} ` },
        ];
        this.multipleCarsDetailsForm.reset();
      }
    }, error => {
      this.messages1 = [
        { severity: 'error', summary: 'Error', detail: `Car Details Creation Failed` },
      ];
    });
  }
}
