import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CarBuzzzService } from 'src/app/services/car-buzzz.service';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css'],
  providers: [ConfirmationService, MessageService]

})
export class DashBoardComponent implements OnInit {
  searchCarByID: any;
  carDetails: any;
  data: any;
  showFiller = false;
  constructor(
    private route: ActivatedRoute, private carBuzzzService: CarBuzzzService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getAllCarDetails();



  }


  getSingleCarDetailsByID() {
    if (this.searchCarByID) {
      this.carBuzzzService.getCarDetailsByID(this.searchCarByID).subscribe(res => {
        if(res){
        console.log("res: " + res.car_id);
        this.carDetails = res;
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Error',key:'carNotFound' ,detail: 'Car Details Not Found' });
          this.carDetails=[];
          
        }
      }, error => { console.log("Error") });
    }
    else {
      this.getAllCarDetails();
    }

  }


  getAllCarDetails() {
    this.carBuzzzService.getAllCarDetails().subscribe(res => {
      this.carDetails = res;
    }, error => { console.log("Error") });

  }

  removeCarDetails(index: any) {
    let carID = this.carDetails[index].car_id;
    this.confirmationService.confirm({
      message: 'Do you want to delete this car?',
      header:`Delete Confirmation CarID : ${carID}`,
      icon: 'pi pi-info-circle',
      accept: () => {
        this.carBuzzzService.removeCarDetails(carID).subscribe(res => {
          this.messageService.add({ severity: 'success', summary: 'Success', key: 'deleteCarIDSucess', detail: `Car ID: ${carID} Successfuly deleted` });
          this.getAllCarDetails();
        }, error => { console.log("Error in Delete") });
      },
      reject: () => {
      }
    });
  }

  updateCarDetails(index:any,rowData:any){
    this.router.navigate(['/addNewCar'],{queryParams:rowData});
  }

}
