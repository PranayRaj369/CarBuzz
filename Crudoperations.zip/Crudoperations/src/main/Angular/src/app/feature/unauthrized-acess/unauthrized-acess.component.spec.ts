import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnauthrizedAcessComponent } from './unauthrized-acess.component';

describe('UnauthrizedAcessComponent', () => {
  let component: UnauthrizedAcessComponent;
  let fixture: ComponentFixture<UnauthrizedAcessComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UnauthrizedAcessComponent]
    });
    fixture = TestBed.createComponent(UnauthrizedAcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
