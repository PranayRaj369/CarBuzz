import { TestBed } from '@angular/core/testing';

import { UrlMapingService } from './url-maping.service';

describe('UrlMapingService', () => {
  let service: UrlMapingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UrlMapingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
