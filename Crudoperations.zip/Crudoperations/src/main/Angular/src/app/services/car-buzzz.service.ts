import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UrlMapingService } from './url-maping.service';

@Injectable({
  providedIn: 'root'
})
export class CarBuzzzService {

  constructor(private httpcClient:HttpClient,private urlMapingService:UrlMapingService) {  }
  
  saveCarDetails(carDetails:any):Observable<any>{
    return this.httpcClient.post<any>(this.urlMapingService.addCarDetails,carDetails)
  }

  saveCarsDetails(carsDetails:any):Observable<any>{
    return this.httpcClient.post<any>(this.urlMapingService.addCarsDetails,carsDetails)
  }

  updateCarDetails(carDetails:any):Observable<any>{
    return this.httpcClient.put<any>(this.urlMapingService.updateCarDetails,carDetails)
  }

  removeCarDetails(carid:any):Observable<any>{
    return this.httpcClient.delete<any>(this.urlMapingService.removeCarDetails+carid)

  }
  getAllCarDetails():Observable<any>{
    return this.httpcClient.get<any>(this.urlMapingService.getCarDetails)

  }

  getCarDetailsByID(carid:any):Observable<any>{
    return this.httpcClient.get<any>(this.urlMapingService.getCarDetailsById+carid)
  }



}
