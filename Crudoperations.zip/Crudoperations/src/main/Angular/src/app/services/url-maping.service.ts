import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UrlMapingService {
  baseURL: any = "http://localhost:9191/";

  addCarDetails=this.baseURL+`addCarDetails`;
  addCarsDetails=this.baseURL+`addCarsDetails`;
  getCarDetails=this.baseURL+`getCarDetails`;
  getCarDetailsById=this.baseURL+`getCarDetailsById/`;
  updateCarDetails=this.baseURL+`updateCarDetails`;
  removeCarDetails=this.baseURL+`removeCarDetails/`;

  constructor() { }


  devEnvironment(){
    
  }

}
