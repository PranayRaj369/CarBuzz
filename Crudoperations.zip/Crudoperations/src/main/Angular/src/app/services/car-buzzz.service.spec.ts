import { TestBed } from '@angular/core/testing';

import { CarBuzzzService } from './car-buzzz.service';

describe('CarBuzzzService', () => {
  let service: CarBuzzzService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CarBuzzzService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
