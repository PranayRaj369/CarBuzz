import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './feature/login/login.component';
import { DashBoardComponent } from './feature/dash-board/dash-board.component';
import { UnauthrizedAcessComponent } from './feature/unauthrized-acess/unauthrized-acess.component';
import { CreateCarDetailsComponent } from './feature/create-car-details/create-car-details.component';

const routes: Routes = [
  {path:'' ,component:DashBoardComponent},
  {path:'app-dash-board',component:DashBoardComponent},
  {path:'app-unauthrized-acess',component:UnauthrizedAcessComponent},
  {path:'addNewCar',component:CreateCarDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
