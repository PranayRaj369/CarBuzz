package com.Lorangtech.crudExample.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.Lorangtech.crudExample.Entity.UserAcountInfo;
import com.Lorangtech.crudExample.Service.UserAcountInfoService;

@RestController
public class UserLoginController {
	
	@Autowired
	UserAcountInfoService userAcountInfoService; 

	@GetMapping("/logintoApplication/{id}/{password}")
	public UserAcountInfo getcarDetailsById(@PathVariable int id,@PathVariable String password ) {
		
		return userAcountInfoService.getuserDetailsById(id, password) ;
	}
}
