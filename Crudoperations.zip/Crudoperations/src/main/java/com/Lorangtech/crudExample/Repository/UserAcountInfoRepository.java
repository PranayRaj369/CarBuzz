package com.Lorangtech.crudExample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Lorangtech.crudExample.Entity.UserAcountInfo;

public interface UserAcountInfoRepository extends JpaRepository<UserAcountInfo, Integer>  {

	@Query(value="from UserAcountInfo where user_id=?1 and password=?2 ")
	UserAcountInfo getlogindetails(int user_id,String password);

}
