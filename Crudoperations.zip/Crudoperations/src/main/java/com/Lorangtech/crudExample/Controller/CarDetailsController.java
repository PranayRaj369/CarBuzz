package com.Lorangtech.crudExample.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Lorangtech.crudExample.Entity.CarDetails;
import com.Lorangtech.crudExample.Service.CarDetailsService;
import com.fasterxml.jackson.annotation.JsonProperty;

@RestController
@CrossOrigin("http://localhost:4200")
public class CarDetailsController {

	@Autowired
	CarDetailsService carDetailsService;
	
	
	@PostMapping("/addCarDetails")
	public CarDetails addCarDetails(@RequestBody CarDetails carDetails) {
		return carDetailsService.saveSingleCarDetails(carDetails);
	}
	
	@PostMapping("/addCarsDetails")
	@JsonProperty("collection")
	public List<CarDetails> addCarsDetails(@RequestBody List<CarDetails> carsDetails ) {
		System.out.println("Inside addcars");
		carsDetails.forEach(i->System.out.println(i));
		return carDetailsService.saveCarsDetails(carsDetails);
	}
	
	@GetMapping("/getCarDetails")
	public List<CarDetails> getAllcarsDetails(){
		return carDetailsService.getCarDetails();
	}
	
	
	@GetMapping("/welcome")
	public String getcarDetailsById( ) {
		return "Hi Welcome to MY APP";
	}
	
	@GetMapping("/getCarDetailsById/{carid}")
	public List<CarDetails> getcarDetailsById( @PathVariable int carid) {
		CarDetails cardetails=carDetailsService.getCarDetailsById(carid);
		List<CarDetails> cardetailsList=new ArrayList<>();
		if(cardetails==null) {
			return null;
		}
		cardetailsList.add(cardetails);
		return cardetailsList ;
	}
	/*
	 * @GetMapping("/getCarDetailsBybrandName/{brandName}") public CarDetails
	 * getcarDetailsBycarName(@PathVariable String brnadName) { return
	 * carDetailsService.getCarDetailsBycar_brandName(brnadName); }
	 */
	
	@PutMapping("/updateCarDetails")
	public CarDetails updateCarDetails(@RequestBody CarDetails carDetails) {
		return carDetailsService.updateCarDetails(carDetails);
	}
	
	
	@DeleteMapping("/removeCarDetails/{carid}")
	public ResponseEntity<Long> removeCarDetails(@PathVariable int carid) {
		Boolean isDelete= carDetailsService.removeCarDetailsBycar_id(carid);
		
		if (!isDelete) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(HttpStatus.OK);
        
		 
	}
	
	
}
