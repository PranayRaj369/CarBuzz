package com.Lorangtech.crudExample.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Lorangtech.crudExample.Entity.CarDetails;
import com.Lorangtech.crudExample.Repository.CarDetailsRepository;

@Service
public class CarDetailsService {

	@Autowired
	private CarDetailsRepository carDetailsRepository;
	
	
	public List<CarDetails> saveCarsDetails(List<CarDetails> carDetails) {
		return carDetailsRepository.saveAll(carDetails);
		
	}
	
	public CarDetails saveSingleCarDetails(CarDetails carDetails) {
		return carDetailsRepository.save(carDetails);
	}
	
	public List<CarDetails> getCarDetails(){
		return carDetailsRepository.findAll();
	}
	
	public CarDetails getCarDetailsById(int car_id){
		return carDetailsRepository.findById(car_id).orElse(null);
	}
	
	/*
	 * public CarDetails getCarDetailsBycar_brandName(String car_brandName){ return
	 * carDetailsRepository.findBycar_brandName(car_brandName); }
	 */
	
	public Boolean removeCarDetailsBycar_id(int car_id) {
		carDetailsRepository.deleteById(car_id);
		Boolean isexist=carDetailsRepository.existsById(car_id);
		if(!isexist) {
			return true;
		}
		return false;
		
	}
	
	
	public  CarDetails updateCarDetails(CarDetails carDetails) {
		CarDetails existingCarDetails= carDetailsRepository.findById(carDetails.getCar_id()).orElse(null);
		
		existingCarDetails.setCar_brandName(carDetails.getCar_brandName());
		existingCarDetails.setCar_model(carDetails.getCar_model());
		existingCarDetails.setCar_price(carDetails.getCar_price());
		existingCarDetails.setCar_stock_count(carDetails.getCar_stock_count());
		return carDetailsRepository.save(existingCarDetails);
		
	}
	
	
}
