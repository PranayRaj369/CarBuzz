package com.Lorangtech.crudExample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Lorangtech.crudExample.Entity.CarDetails;

public interface CarDetailsRepository extends JpaRepository<CarDetails, Integer> {


}
