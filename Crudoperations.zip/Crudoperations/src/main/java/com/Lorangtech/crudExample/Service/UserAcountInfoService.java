package com.Lorangtech.crudExample.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Lorangtech.crudExample.Entity.UserAcountInfo;
import com.Lorangtech.crudExample.Repository.UserAcountInfoRepository;

@Service
public class UserAcountInfoService {

	@Autowired
	UserAcountInfoRepository userAcountInfoRepository; 
	
	public UserAcountInfo getuserDetailsById(int id,String password) {
		return userAcountInfoRepository.getlogindetails(id,password);
	}
}
