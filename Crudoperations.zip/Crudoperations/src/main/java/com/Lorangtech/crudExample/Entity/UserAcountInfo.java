package com.Lorangtech.crudExample.Entity;

import java.awt.geom.Arc2D.Double;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name="USER_ACOUNT_DTLS")
public class UserAcountInfo {

	@Id
	@GeneratedValue
	private int user_id;
	private String firstName;
	private String secondName;
	private String address;
	private String password;
	private int age;
	
}
