package com.Lorangtech.crudExample.Entity;

import java.awt.geom.Arc2D.Double;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="CAR_DTLS_TBL")
public class CarDetails {
	
	@TableGenerator(name = "CarID_Gen", initialValue = 10000, allocationSize = 10)
	  @Id
	  @GeneratedValue(strategy = GenerationType.TABLE, generator = "CarID_Gen")
	private int car_id;
	private String car_brandName;
	private String car_model;
	private int car_stock_count;
	private int car_price;

}
