package com.Lorangtech.crudExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudoperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
